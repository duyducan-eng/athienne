# -*- coding: utf-8 -*-
import sys
import json
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.fshare import (
    FshareClient, FshareError, item_to_url, is_folder_item, format_size
)

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
ADDON = xbmcaddon.Addon()
PHIM_API = "https://phimapi.com"
PHIM_IMG = "https://phimimg.com/"
UA = "Mozilla/5.0 (Kodi Athienne/1.2.0)"

def notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification("Athienne", str(msg), icon, 5000)

def build_url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)

def add_dir(label, action, art=None, **params):
    li = xbmcgui.ListItem(label=label)
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action, **params), li, True)

def add_play(label, action, art=None, **params):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": label})
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action, **params), li, False)

def http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept":"application/json,*/*"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode("utf-8","replace"))

def normalize_movies(data):
    if isinstance(data, dict):
        for key in ("items","data"):
            v=data.get(key)
            if isinstance(v,list): return v
            if isinstance(v,dict):
                for sub in ("items","data"):
                    if isinstance(v.get(sub),list): return v[sub]
    return data if isinstance(data,list) else []

def poster_url(m):
    p=m.get("poster_url") or m.get("thumb_url") or ""
    if p and not p.startswith("http"):
        p=PHIM_IMG + p.lstrip("/")
    return p

def home():
    add_dir("🔥 Phim mới cập nhật", "movies", page="1")
    add_dir("🔎 Tìm kiếm phim", "search")
    add_dir("☁️ Fshare", "fshare_menu")
    xbmcplugin.endOfDirectory(HANDLE)

def movies(page="1"):
    try:
        data=http_json(PHIM_API + "/danh-sach/phim-moi-cap-nhat?page=" + urllib.parse.quote(str(page)))
        items=normalize_movies(data)
        for m in items:
            name=m.get("name") or m.get("origin_name") or m.get("title") or "Không tên"
            slug=m.get("slug") or ""
            if not slug: continue
            p=poster_url(m)
            add_dir(name,"detail",{"poster":p,"thumb":p},slug=slug,poster=p)
        add_dir("Trang tiếp theo ▶","movies",page=str(int(page)+1))
    except Exception as e:
        notify("Lỗi tải danh sách phim: %s" % e, True)
    xbmcplugin.setContent(HANDLE,"movies")
    xbmcplugin.endOfDirectory(HANDLE)

def detail(slug, poster=""):
    try:
        d=http_json(PHIM_API + "/phim/" + urllib.parse.quote(slug))
        movie=d.get("movie",{}) if isinstance(d,dict) else {}
        eps=d.get("episodes",[]) if isinstance(d,dict) else []
        count=0
        for server in eps:
            sn=server.get("server_name","Server")
            for ep in server.get("server_data",[]):
                stream=ep.get("link_m3u8") or ep.get("link_embed")
                if not stream: continue
                label="%s - %s" % (sn, ep.get("name",""))
                add_play(label,"play",{"poster":poster,"thumb":poster},url=stream)
                count+=1
        if not count: notify("Phim chưa có nguồn phát.")
    except Exception as e:
        notify("Lỗi chi tiết phim: %s" % e, True)
    xbmcplugin.setContent(HANDLE,"episodes")
    xbmcplugin.endOfDirectory(HANDLE)

def search():
    q=xbmcgui.Dialog().input("Tên phim", type=xbmcgui.INPUT_ALPHANUM)
    if not q:
        xbmcplugin.endOfDirectory(HANDLE); return
    try:
        url=PHIM_API + "/v1/api/tim-kiem?keyword=" + urllib.parse.quote(q)
        data=http_json(url)
        items=normalize_movies(data)
        for m in items:
            name=m.get("name") or m.get("origin_name") or "Không tên"
            slug=m.get("slug") or ""
            if slug:
                p=poster_url(m)
                add_dir(name,"detail",{"poster":p,"thumb":p},slug=slug,poster=p)
        if not items: notify("Không tìm thấy phim.")
    except Exception as e:
        notify("Lỗi tìm kiếm: %s" % e, True)
    xbmcplugin.endOfDirectory(HANDLE)

def play(url):
    li=xbmcgui.ListItem(path=url)
    if ".m3u8" in url.lower():
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE,True,li)

def fs_client():
    return FshareClient(
        ADDON.getSetting("fshare_email"),
        ADDON.getSetting("fshare_password"),
        ADDON.getSetting("fshare_app_key"),
        ADDON.getSetting("fshare_token"),
        ADDON.getSetting("fshare_session"),
    )

def save_fs_session(c):
    ADDON.setSetting("fshare_token", c.token or "")
    ADDON.setSetting("fshare_session", c.session_id or "")

def fs_login(force=False):
    c=fs_client()
    try:
        if force:
            c.token=c.session_id=""
        if not c.token or not c.session_id:
            c.login()
        save_fs_session(c)
        notify("Đăng nhập Fshare thành công.")
        return c
    except FshareError as e:
        notify(str(e), True)
        return None

def fshare_menu():
    add_dir("📁 Tệp của tôi", "fshare_home")
    add_dir("🔗 Mở link Fshare", "fshare_open")
    add_dir("👤 Thông tin tài khoản", "fshare_profile")
    add_dir("🔐 Đăng nhập lại", "fshare_login")
    add_dir("⚙️ Cài đặt Fshare", "fshare_settings")
    xbmcplugin.endOfDirectory(HANDLE)

def fshare_settings():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(HANDLE)

def fshare_login():
    fs_login(True)
    xbmcplugin.endOfDirectory(HANDLE)

def fshare_profile():
    c=fs_login(False)
    if not c:
        xbmcplugin.endOfDirectory(HANDLE); return
    try:
        d=c.profile()
        save_fs_session(c)
        lines=[]
        for key,label in (
            ("email","Email"),("account_type","Loại tài khoản"),("expire_vip","VIP đến"),
            ("totalpoints","Điểm"),("webspace","Dung lượng"),("webspace_used","Đã dùng")
        ):
            if key in d: lines.append("%s: %s" % (label,d.get(key)))
        xbmcgui.Dialog().textviewer("Fshare", "\n".join(lines) if lines else json.dumps(d,ensure_ascii=False,indent=2))
    except Exception as e:
        notify(str(e), True)
    xbmcplugin.endOfDirectory(HANDLE)

def fshare_home():
    c=fs_login(False)
    if not c:
        xbmcplugin.endOfDirectory(HANDLE); return
    try:
        items=c.list_home()
        save_fs_session(c)
        add_fshare_items(items)
    except Exception as e:
        notify(str(e), True)
    xbmcplugin.setContent(HANDLE,"files")
    xbmcplugin.endOfDirectory(HANDLE)

def add_fshare_items(items):
    show_size=ADDON.getSetting("show_file_size").lower()!="false"
    for it in items:
        name=str(it.get("name") or it.get("filename") or "Không tên")
        u=item_to_url(it)
        if not u: continue
        folder=is_folder_item(it)
        size=format_size(it.get("size",0))
        label=name + (("  ["+size+"]") if show_size and size and not folder else "")
        if folder:
            add_dir("📁 "+label,"fshare_folder",url=u)
        else:
            add_play("▶ "+label,"fshare_play",url=u)

def fshare_folder(url):
    c=fs_login(False)
    if not c:
        xbmcplugin.endOfDirectory(HANDLE); return
    try:
        items=c.list_folder(url)
        save_fs_session(c)
        add_fshare_items(items)
    except Exception as e:
        notify(str(e), True)
    xbmcplugin.setContent(HANDLE,"files")
    xbmcplugin.endOfDirectory(HANDLE)

def fshare_open():
    u=xbmcgui.Dialog().input("Dán link Fshare", type=xbmcgui.INPUT_ALPHANUM)
    if not u:
        xbmcplugin.endOfDirectory(HANDLE); return
    if "/folder/" in u:
        fshare_folder(u)
        return
    fshare_play(u)

def fshare_play(url):
    c=fs_login(False)
    if not c:
        xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem()); return
    try:
        try:
            direct=c.download(url)
        except FshareError as e:
            if str(e)=="PASSWORD_REQUIRED":
                pw=xbmcgui.Dialog().input("Mật khẩu file Fshare", option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not pw: raise FshareError("Đã hủy nhập mật khẩu file.")
                direct=c.download(url,pw)
            else:
                raise
        save_fs_session(c)
        li=xbmcgui.ListItem(path=direct)
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(HANDLE,True,li)
    except Exception as e:
        notify(str(e), True)
        xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem())

params=dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action=params.get("action")
try:
    if not action: home()
    elif action=="movies": movies(params.get("page","1"))
    elif action=="detail": detail(params.get("slug",""),params.get("poster",""))
    elif action=="search": search()
    elif action=="play": play(params.get("url",""))
    elif action=="fshare_menu": fshare_menu()
    elif action=="fshare_settings": fshare_settings()
    elif action=="fshare_login": fshare_login()
    elif action=="fshare_profile": fshare_profile()
    elif action=="fshare_home": fshare_home()
    elif action=="fshare_folder": fshare_folder(params.get("url",""))
    elif action=="fshare_open": fshare_open()
    elif action=="fshare_play": fshare_play(params.get("url",""))
except Exception as e:
    xbmc.log("Athienne error: "+repr(e),xbmc.LOGERROR)
    notify("Lỗi: %s" % e, True)
    try: xbmcplugin.endOfDirectory(HANDLE)
    except Exception: pass
