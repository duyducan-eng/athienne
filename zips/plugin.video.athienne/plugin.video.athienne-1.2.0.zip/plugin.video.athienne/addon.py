# -*- coding: utf-8 -*-
import sys, json, os, time, urllib.parse, urllib.request
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
API = "https://phimapi.com"
UA = "Mozilla/5.0 (Kodi Athienne/1.2.0)"
ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
SEARCH_FILE = os.path.join(PROFILE, "search_history.json")
WATCH_FILE = os.path.join(PROFILE, "watch_history.json")
PENDING_FILE = os.path.join(PROFILE, "pending_play.json")
MAX_SEARCH_HISTORY = 30
MAX_WATCH_HISTORY = 100

GENRES = [
    ("Hành Động", "hanh-dong"), ("Tình Cảm", "tinh-cam"),
    ("Hài Hước", "hai-huoc"), ("Cổ Trang", "co-trang"),
    ("Tâm Lý", "tam-ly"), ("Hình Sự", "hinh-su"),
    ("Chiến Tranh", "chien-tranh"), ("Thể Thao", "the-thao"),
    ("Võ Thuật", "vo-thuat"), ("Viễn Tưởng", "vien-tuong"),
    ("Phiêu Lưu", "phieu-luu"), ("Khoa Học", "khoa-hoc"),
    ("Kinh Dị", "kinh-di"), ("Âm Nhạc", "am-nhac"),
    ("Thần Thoại", "than-thoai"), ("Tài Liệu", "tai-lieu"),
    ("Gia Đình", "gia-dinh"), ("Chính Kịch", "chinh-kich"),
    ("Bí Ẩn", "bi-an"), ("Học Đường", "hoc-duong")
]

COUNTRIES = [
    ("Việt Nam", "viet-nam"), ("Trung Quốc", "trung-quoc"),
    ("Hàn Quốc", "han-quoc"), ("Nhật Bản", "nhat-ban"),
    ("Thái Lan", "thai-lan"), ("Âu Mỹ", "au-my"),
    ("Anh", "anh"), ("Pháp", "phap"), ("Ấn Độ", "an-do"),
    ("Hồng Kông", "hong-kong"), ("Đài Loan", "dai-loan"),
    ("Canada", "canada"), ("Úc", "uc")
]

VIDEO_EXTS = (".m3u8", ".mp4", ".mkv", ".avi", ".mov", ".ts", ".webm")

def ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)

def load_json_file(path, default):
    ensure_profile()
    try:
        if not xbmcvfs.exists(path):
            return default
        f = xbmcvfs.File(path)
        raw = f.read()
        f.close()
        obj = json.loads(raw) if raw else default
        return obj
    except Exception:
        return default

def save_json_file(path, obj):
    ensure_profile()
    tmp = path + ".tmp"
    f = xbmcvfs.File(tmp, "w")
    f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    f.close()
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
        xbmcvfs.rename(tmp, path)
    except Exception:
        try:
            f = xbmcvfs.File(path, "w")
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
            f.close()
            if xbmcvfs.exists(tmp):
                xbmcvfs.delete(tmp)
        except Exception:
            pass

def notify(msg):
    xbmcgui.Dialog().notification("Athienne", msg, xbmcgui.NOTIFICATION_INFO, 5000)

def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))

def purl(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)

def full_image(path, prefix=""):
    if not path: return ""
    if path.startswith("http://") or path.startswith("https://"): return path
    if prefix: return prefix.rstrip("/") + "/" + path.lstrip("/")
    return API + "/uploads/movies/" + path.lstrip("/")

def add_dir(label, action, art=None, **kw):
    li = xbmcgui.ListItem(label=label)
    if art: li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, purl(action=action, **kw), li, True)

def add_play(label, url, art=None, **meta):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": label})
    if art: li.setArt(art)
    payload = {"action": "play", "url": url, "label": label}
    payload.update({k: v for k, v in meta.items() if v is not None})
    xbmcplugin.addDirectoryItem(HANDLE, purl(**payload), li, False)

def extract_items(data):
    if isinstance(data, dict):
        if isinstance(data.get("items"), list):
            return data["items"], data.get("pathImage", "")
        d = data.get("data")
        if isinstance(d, dict) and isinstance(d.get("items"), list):
            app = d.get("APP_DOMAIN_CDN_IMAGE") or d.get("pathImage") or ""
            return d["items"], app
    return [], ""

def save_search_query(q):
    q = (q or "").strip()
    if not q: return
    rows = load_json_file(SEARCH_FILE, [])
    rows = [x for x in rows if isinstance(x, dict) and x.get("q", "").lower() != q.lower()]
    rows.insert(0, {"q": q, "ts": int(time.time())})
    save_json_file(SEARCH_FILE, rows[:MAX_SEARCH_HISTORY])

def history_key(slug, server, episode):
    return "|".join([slug or "", server or "", episode or ""])

def save_pending(meta):
    save_json_file(PENDING_FILE, meta)

def clear_pending():
    try:
        if xbmcvfs.exists(PENDING_FILE):
            xbmcvfs.delete(PENDING_FILE)
    except Exception:
        pass

def home():
    add_dir("▶ Xem tiếp", "watch_history")
    add_dir("🔥 Phim mới cập nhật", "latest", page="1")
    add_dir("🆕 Phim mới", "catalog", kind="danh-sach", slug="phim-moi", page="1")
    add_dir("🎬 Phim lẻ", "catalog", kind="danh-sach", slug="phim-le", page="1")
    add_dir("📺 Phim bộ", "catalog", kind="danh-sach", slug="phim-bo", page="1")
    add_dir("🎨 Hoạt hình", "catalog", kind="danh-sach", slug="hoat-hinh", page="1")
    add_dir("🍿 Phim chiếu rạp", "catalog", kind="danh-sach", slug="phim-chieu-rap", page="1")
    add_dir("💬 Vietsub", "catalog", kind="danh-sach", slug="phim-vietsub", page="1")
    add_dir("🔊 Thuyết minh", "catalog", kind="danh-sach", slug="phim-thuyet-minh", page="1")
    add_dir("🎙 Lồng tiếng", "catalog", kind="danh-sach", slug="phim-long-tieng", page="1")
    add_dir("🎭 Thể loại", "genres")
    add_dir("🌍 Quốc gia", "countries")
    add_dir("🔎 Tìm kiếm", "search")
    add_dir("🕘 Lịch sử tìm kiếm", "search_history")
    xbmcplugin.endOfDirectory(HANDLE)

def genres():
    for name, slug in GENRES:
        add_dir(name, "catalog", kind="the-loai", slug=slug, page="1")
    xbmcplugin.endOfDirectory(HANDLE)

def countries():
    for name, slug in COUNTRIES:
        add_dir(name, "catalog", kind="quoc-gia", slug=slug, page="1")
    xbmcplugin.endOfDirectory(HANDLE)

def render_movies(data, next_action=None, next_page=None, next_kwargs=None):
    items, prefix = extract_items(data)
    for m in items:
        name = m.get("name") or m.get("origin_name") or "Không tên"
        slug = m.get("slug") or ""
        poster = full_image(m.get("poster_url") or m.get("thumb_url") or "", prefix)
        label = name
        year = m.get("year")
        episode = m.get("episode_current")
        if year: label += " (%s)" % year
        if episode: label += " - %s" % episode
        if slug:
            add_dir(label, "detail", {"poster": poster, "thumb": poster}, slug=slug, poster=poster, movie=name)
    if next_action and items:
        kw = dict(next_kwargs or {})
        kw["page"] = str(next_page)
        add_dir("Trang tiếp theo ▶", next_action, **kw)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)

def latest(page):
    url = API + "/danh-sach/phim-moi-cap-nhat?page=" + urllib.parse.quote(str(page))
    render_movies(get_json(url), "latest", int(page)+1)

def catalog(kind, slug, page):
    url = API + "/v1/api/%s/%s?%s" % (
        urllib.parse.quote(kind), urllib.parse.quote(slug),
        urllib.parse.urlencode({"page": page, "limit": 24})
    )
    render_movies(get_json(url), "catalog", int(page)+1, {"kind": kind, "slug": slug})

def detail(slug, poster="", movie=""):
    data = get_json(API + "/phim/" + urllib.parse.quote(slug))
    episodes = data.get("episodes", []) if isinstance(data, dict) else []
    movie_data = data.get("movie", {}) if isinstance(data, dict) else {}
    if not movie and isinstance(movie_data, dict):
        movie = movie_data.get("name") or movie_data.get("origin_name") or slug
    if not poster and isinstance(movie_data, dict):
        poster = full_image(movie_data.get("poster_url") or movie_data.get("thumb_url") or "")
    count = 0
    for server in episodes:
        sname = server.get("server_name", "Server")
        for ep in server.get("server_data", []):
            stream = ep.get("link_m3u8") or ep.get("link_embed")
            if not stream: continue
            epname = ep.get("name", "")
            label = "%s - Tập %s" % (sname, epname)
            add_play(label, stream, {"poster": poster, "thumb": poster},
                     slug=slug, movie=movie, poster=poster, server=sname, episode=epname)
            count += 1
    if not count: notify("Phim chưa có nguồn phát.")
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)

def do_search(q):
    q = (q or "").strip()
    if not q:
        xbmcplugin.endOfDirectory(HANDLE); return
    save_search_query(q)
    url = API + "/v1/api/tim-kiem?" + urllib.parse.urlencode({"keyword": q, "limit": 50})
    render_movies(get_json(url))

def search():
    q = xbmcgui.Dialog().input("Nhập tên phim", type=xbmcgui.INPUT_ALPHANUM)
    do_search(q)

def search_history():
    rows = load_json_file(SEARCH_FILE, [])
    if rows:
        add_dir("🗑 Xóa lịch sử tìm kiếm", "clear_search_history")
    for row in rows:
        q = row.get("q", "") if isinstance(row, dict) else ""
        if q:
            add_dir("🔎 " + q, "search_query", q=q)
    xbmcplugin.endOfDirectory(HANDLE)

def clear_search_history():
    save_json_file(SEARCH_FILE, [])
    notify("Đã xóa lịch sử tìm kiếm.")
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)

def fmt_time(seconds):
    try:
        seconds = max(0, int(float(seconds)))
    except Exception:
        seconds = 0
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return ("%d:%02d:%02d" % (h, m, s)) if h else ("%02d:%02d" % (m, s))

def watch_history():
    rows = load_json_file(WATCH_FILE, [])
    rows = [r for r in rows if isinstance(r, dict)]
    rows.sort(key=lambda r: int(r.get("updated", 0)), reverse=True)
    if rows:
        add_dir("🗑 Xóa lịch sử xem", "clear_watch_history")
    for r in rows:
        position = float(r.get("position", 0) or 0)
        total = float(r.get("total", 0) or 0)
        percent = int(position * 100 / total) if total > 0 else 0
        movie = r.get("movie") or r.get("slug") or "Phim"
        ep = r.get("episode") or ""
        server = r.get("server") or ""
        label = "▶ %s" % movie
        if ep: label += " - Tập %s" % ep
        if percent > 0: label += "  [%d%% • %s]" % (percent, fmt_time(position))
        art = {"poster": r.get("poster", ""), "thumb": r.get("poster", "")} if r.get("poster") else None
        add_play(label, r.get("url", ""), art,
                 slug=r.get("slug",""), movie=movie, poster=r.get("poster",""),
                 server=server, episode=ep, resume=str(position))
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)

def clear_watch_history():
    save_json_file(WATCH_FILE, [])
    clear_pending()
    notify("Đã xóa lịch sử xem.")
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)

def play(url, label="", slug="", movie="", poster="", server="", episode="", resume="0"):
    if not url:
        notify("Không có nguồn phát."); return
    try:
        resume_seconds = max(0.0, float(resume or 0))
    except Exception:
        resume_seconds = 0.0
    meta = {
        "key": history_key(slug, server, episode),
        "url": url, "label": label, "slug": slug, "movie": movie or slug,
        "poster": poster, "server": server, "episode": episode,
        "resume": resume_seconds, "started": int(time.time())
    }
    save_pending(meta)
    li = xbmcgui.ListItem(path=url)
    li.setInfo("video", {"title": label or movie or "Athienne"})
    if poster: li.setArt({"poster": poster, "thumb": poster})
    if ".m3u8" in url.lower():
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    if resume_seconds > 5:
        li.setProperty("StartOffset", str(int(resume_seconds)))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action")
try:
    if not action: home()
    elif action == "latest": latest(params.get("page", "1"))
    elif action == "catalog": catalog(params.get("kind", "danh-sach"), params.get("slug", "phim-le"), params.get("page", "1"))
    elif action == "genres": genres()
    elif action == "countries": countries()
    elif action == "detail": detail(params.get("slug", ""), params.get("poster", ""), params.get("movie", ""))
    elif action == "search": search()
    elif action == "search_query": do_search(params.get("q", ""))
    elif action == "search_history": search_history()
    elif action == "clear_search_history": clear_search_history()
    elif action == "watch_history": watch_history()
    elif action == "clear_watch_history": clear_watch_history()
    elif action == "play":
        play(params.get("url", ""), params.get("label", ""), params.get("slug", ""),
             params.get("movie", ""), params.get("poster", ""), params.get("server", ""),
             params.get("episode", ""), params.get("resume", "0"))
except Exception as e:
    xbmc.log("Athienne error: " + repr(e), xbmc.LOGERROR)
    notify("Lỗi: " + str(e)[:120])
    try: xbmcplugin.endOfDirectory(HANDLE)
    except Exception: pass
