# -*- coding: utf-8 -*-
import os, json, time
import xbmc, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
WATCH_FILE = os.path.join(PROFILE, "watch_history.json")
PENDING_FILE = os.path.join(PROFILE, "pending_play.json")
MAX_WATCH_HISTORY = 100

def ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)

def load_json_file(path, default):
    ensure_profile()
    try:
        if not xbmcvfs.exists(path): return default
        f = xbmcvfs.File(path); raw = f.read(); f.close()
        return json.loads(raw) if raw else default
    except Exception:
        return default

def save_json_file(path, obj):
    ensure_profile()
    tmp = path + ".tmp"
    try:
        f = xbmcvfs.File(tmp, "w")
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
        f.close()
        if xbmcvfs.exists(path): xbmcvfs.delete(path)
        xbmcvfs.rename(tmp, path)
    except Exception:
        try:
            f = xbmcvfs.File(path, "w")
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
            f.close()
        except Exception:
            pass

def clear_pending():
    try:
        if xbmcvfs.exists(PENDING_FILE): xbmcvfs.delete(PENDING_FILE)
    except Exception:
        pass

def upsert_watch(meta, position, total):
    if not meta: return
    key = meta.get("key") or "|".join([meta.get("slug",""), meta.get("server",""), meta.get("episode","")])
    if not key.strip("|"): return
    row = {
        "key": key,
        "url": meta.get("url",""),
        "label": meta.get("label",""),
        "slug": meta.get("slug",""),
        "movie": meta.get("movie","") or meta.get("slug",""),
        "poster": meta.get("poster",""),
        "server": meta.get("server",""),
        "episode": meta.get("episode",""),
        "position": max(0, float(position or 0)),
        "total": max(0, float(total or 0)),
        "updated": int(time.time())
    }
    rows = load_json_file(WATCH_FILE, [])
    rows = [r for r in rows if isinstance(r, dict) and r.get("key") != key]
    # Consider >= 92% watched as completed: remove from "Xem tiếp".
    if row["total"] > 60 and row["position"] / row["total"] >= 0.92:
        save_json_file(WATCH_FILE, rows[:MAX_WATCH_HISTORY])
        return
    rows.insert(0, row)
    save_json_file(WATCH_FILE, rows[:MAX_WATCH_HISTORY])

class Monitor(xbmc.Player):
    def __init__(self):
        super(Monitor, self).__init__()
        self.meta = None
        self.resume_applied = False

    def onAVStarted(self):
        self.meta = load_json_file(PENDING_FILE, {})
        self.resume_applied = False
        if not self.meta:
            return
        resume = float(self.meta.get("resume", 0) or 0)
        if resume > 5:
            try:
                # setResolvedUrl StartOffset is not honored by every stream/inputstream.
                # Seek again after AV has started as fallback.
                self.seekTime(resume)
                self.resume_applied = True
            except Exception:
                pass

    def snapshot(self):
        if not self.meta: return
        try: pos = self.getTime()
        except Exception: pos = 0
        try: total = self.getTotalTime()
        except Exception: total = 0
        if pos >= 3:
            upsert_watch(self.meta, pos, total)

    def onPlayBackStopped(self):
        self.snapshot()
        self.meta = None
        clear_pending()

    def onPlayBackEnded(self):
        if self.meta:
            try: total = self.getTotalTime()
            except Exception: total = 0
            if total > 0: upsert_watch(self.meta, total, total)
        self.meta = None
        clear_pending()

    def onPlayBackError(self):
        self.snapshot()
        self.meta = None
        clear_pending()

player = Monitor()
monitor = xbmc.Monitor()
last_save = 0
while not monitor.abortRequested():
    if player.isPlayingVideo() and player.meta:
        now = time.time()
        if now - last_save >= 10:
            player.snapshot()
            last_save = now
    if monitor.waitForAbort(1):
        break
