# -*- coding: utf-8 -*-
import json
import urllib.request
import urllib.parse
import urllib.error

LOGIN_API = "https://api.fshare.vn/api/user/login"
PROFILE_API = "https://api.fshare.vn/api/user/get"
DOWNLOAD_API = "https://api.fshare.vn/api/session/download"
FOLDER_API = "https://api.fshare.vn/api/fileops/getFolderList"
LIST_API = "https://api.fshare.vn/api/fileops/list"
UA = "Athienne-Kodi/1.2.0"

class FshareError(Exception):
    pass

class FshareClient:
    def __init__(self, email="", password="", app_key="", token="", session_id=""):
        self.email = (email or "").strip()
        self.password = (password or "").strip()
        self.app_key = (app_key or "").strip()
        self.token = (token or "").strip()
        self.session_id = (session_id or "").strip()

    def _headers(self, json_body=False):
        h = {
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
        }
        if json_body:
            h["Content-Type"] = "application/json"
        if self.session_id:
            h["Cookie"] = "session_id=" + self.session_id
        return h

    def _request(self, url, payload=None, method=None):
        data = None
        headers = self._headers(payload is not None)
        if payload is not None:
            data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method=method or ("POST" if data is not None else "GET"),
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read().decode("utf-8", "replace")
                if not raw:
                    return {}
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", "replace")
            try:
                obj = json.loads(raw) if raw else {}
            except Exception:
                obj = {"msg": raw or e.reason}
            obj["_http_status"] = e.code
            return obj
        except Exception as e:
            raise FshareError("Không kết nối được Fshare: %s" % e)

    def login(self):
        if not self.email or not self.password:
            raise FshareError("Chưa nhập tài khoản hoặc mật khẩu Fshare.")
        if not self.app_key:
            raise FshareError(
                "Chưa nhập Fshare App Key. Fshare hiện yêu cầu App Key được cấp cho đối tác/API."
            )
        obj = self._request(
            LOGIN_API,
            {
                "user_email": self.email,
                "password": self.password,
                "app_key": self.app_key,
            },
        )
        code = obj.get("code", obj.get("_http_status"))
        if code != 200:
            raise FshareError(obj.get("msg") or obj.get("error") or "Đăng nhập Fshare thất bại.")
        self.token = obj.get("token", "")
        self.session_id = obj.get("session_id", "")
        if not self.token or not self.session_id:
            raise FshareError("Fshare không trả token/session hợp lệ.")
        return obj

    def ensure_login(self):
        if self.token and self.session_id:
            return True
        self.login()
        return True

    def profile(self):
        self.ensure_login()
        obj = self._request(PROFILE_API)
        status = obj.get("_http_status")
        if status in (401, 201, 403):
            self.token = self.session_id = ""
            self.login()
            obj = self._request(PROFILE_API)
        return obj

    def list_home(self, page=0, limit=100, path=""):
        self.ensure_login()
        qs = urllib.parse.urlencode({
            "pageIndex": int(page),
            "dirOnly": 0,
            "limit": int(limit),
            "path": path or "",
        })
        obj = self._request(LIST_API + "?" + qs)
        if isinstance(obj, dict) and obj.get("_http_status") in (401, 201, 403):
            self.token = self.session_id = ""
            self.login()
            obj = self._request(LIST_API + "?" + qs)
        return self._items(obj)

    def list_folder(self, folder_url, page=0, limit=100):
        self.ensure_login()
        obj = self._request(
            FOLDER_API,
            {
                "token": self.token,
                "url": normalize_fshare_url(folder_url),
                "dirOnly": 0,
                "pageIndex": int(page),
                "limit": int(limit),
            },
        )
        if isinstance(obj, dict) and obj.get("_http_status") in (401, 201, 403):
            self.token = self.session_id = ""
            self.login()
            obj = self._request(
                FOLDER_API,
                {
                    "token": self.token,
                    "url": normalize_fshare_url(folder_url),
                    "dirOnly": 0,
                    "pageIndex": int(page),
                    "limit": int(limit),
                },
            )
        return self._items(obj)

    @staticmethod
    def _items(obj):
        if isinstance(obj, list):
            return obj
        if isinstance(obj, dict):
            for key in ("items", "data", "files"):
                val = obj.get(key)
                if isinstance(val, list):
                    return val
                if isinstance(val, dict):
                    for sub in ("items", "data", "files"):
                        if isinstance(val.get(sub), list):
                            return val[sub]
            if obj.get("msg") or obj.get("error"):
                raise FshareError(obj.get("msg") or obj.get("error"))
        return []

    def download(self, file_url, password=""):
        self.ensure_login()
        payload = {
            "zipflag": 0,
            "url": normalize_fshare_url(file_url),
            "password": password or "",
            "token": self.token,
        }
        obj = self._request(DOWNLOAD_API, payload)
        status = obj.get("_http_status")
        if status in (401, 201, 403):
            self.token = self.session_id = ""
            self.login()
            payload["token"] = self.token
            obj = self._request(DOWNLOAD_API, payload)
        if obj.get("code") == 123:
            raise FshareError("PASSWORD_REQUIRED")
        location = obj.get("location")
        if location:
            return location
        raise FshareError(obj.get("msg") or obj.get("error") or "Không lấy được direct link Fshare.")

def normalize_fshare_url(url):
    url = (url or "").strip()
    if not url:
        raise FshareError("Link Fshare trống.")
    if "fshare.vn" not in url:
        raise FshareError("Đây không phải link Fshare.")
    url = url.split("?")[0].rstrip("/")
    return url

def item_to_url(item):
    link = item.get("url") or item.get("link") or ""
    if link and "fshare.vn" in str(link):
        return str(link)
    code = item.get("linkcode") or item.get("code") or item.get("id") or ""
    is_folder = is_folder_item(item)
    if not code:
        return ""
    kind = "folder" if is_folder else "file"
    return "https://www.fshare.vn/%s/%s" % (kind, code)

def is_folder_item(item):
    t = item.get("type")
    if t in (0, "0", "folder", "dir", "directory"):
        return True
    if item.get("is_folder") is True or item.get("isFolder") is True:
        return True
    u = str(item.get("url") or item.get("link") or "")
    return "/folder/" in u

def format_size(size):
    try:
        n = float(size)
    except Exception:
        return ""
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while n >= 1024 and i < len(units)-1:
        n /= 1024.0
        i += 1
    return ("%.2f %s" % (n, units[i])) if i else ("%d B" % n)
