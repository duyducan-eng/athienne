# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request
import xbmc, xbmcgui, xbmcplugin

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
API = "https://phimapi.com"
UA = "Mozilla/5.0 (Kodi Athienne/1.1.0)"

GENRES = [
    ("Hành Động", "hanh-dong"), ("Tình Cảm", "tinh-cam"),
    ("Hài Hước", "hai-huoc"), ("Cổ Trang", "co-trang"),
    ("Tâm Lý", "tam-ly"), ("Hình Sự", "hinh-su"),
    ("Chiến Tranh", "chien-tranh"), ("Thể Thao", "the-thao"),
    ("Võ Thuật", "vo-thuat"), ("Viễn Tưởng", "vien-tuong"),
    ("Phiêu Lưu", "phieu-luu"), ("Khoa Học", "khoa-hoc"),
    ("Kinh Dị", "kinh-di"), ("Âm Nhạc", "am-nhac"),
    ("Thần Thoại", "than-thoai"), ("Tài Liệu", "tai-lieu"),
    ("Gia Đình", "gia-dinh"), ("Chính Kịch", "chinh-kich"),
    ("Bí Ẩn", "bi-an"), ("Học Đường", "hoc-duong")
]

COUNTRIES = [
    ("Việt Nam", "viet-nam"), ("Trung Quốc", "trung-quoc"),
    ("Hàn Quốc", "han-quoc"), ("Nhật Bản", "nhat-ban"),
    ("Thái Lan", "thai-lan"), ("Âu Mỹ", "au-my"),
    ("Anh", "anh"), ("Pháp", "phap"), ("Ấn Độ", "an-do"),
    ("Hồng Kông", "hong-kong"), ("Đài Loan", "dai-loan"),
    ("Canada", "canada"), ("Úc", "uc")
]

def notify(msg):
    xbmcgui.Dialog().notification("Athienne", msg, xbmcgui.NOTIFICATION_INFO, 5000)

def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))

def purl(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)

def full_image(path, prefix=""):
    if not path: return ""
    if path.startswith("http://") or path.startswith("https://"): return path
    if prefix: return prefix.rstrip("/") + "/" + path.lstrip("/")
    return API + "/uploads/movies/" + path.lstrip("/")

def add_dir(label, action, art=None, **kw):
    li = xbmcgui.ListItem(label=label)
    if art: li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, purl(action=action, **kw), li, True)

def add_play(label, url, art=None):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": label})
    if art: li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, purl(action="play", url=url), li, False)

def extract_items(data):
    if isinstance(data, dict):
        if isinstance(data.get("items"), list):
            return data["items"], data.get("pathImage", "")
        d = data.get("data")
        if isinstance(d, dict) and isinstance(d.get("items"), list):
            app = d.get("APP_DOMAIN_CDN_IMAGE") or d.get("pathImage") or ""
            return d["items"], app
    return [], ""

def home():
    add_dir("🔥 Phim mới cập nhật", "latest", page="1")
    add_dir("🆕 Phim mới", "catalog", kind="danh-sach", slug="phim-moi", page="1")
    add_dir("🎬 Phim lẻ", "catalog", kind="danh-sach", slug="phim-le", page="1")
    add_dir("📺 Phim bộ", "catalog", kind="danh-sach", slug="phim-bo", page="1")
    add_dir("🎨 Hoạt hình", "catalog", kind="danh-sach", slug="hoat-hinh", page="1")
    add_dir("🍿 Phim chiếu rạp", "catalog", kind="danh-sach", slug="phim-chieu-rap", page="1")
    add_dir("💬 Vietsub", "catalog", kind="danh-sach", slug="phim-vietsub", page="1")
    add_dir("🔊 Thuyết minh", "catalog", kind="danh-sach", slug="phim-thuyet-minh", page="1")
    add_dir("🎙 Lồng tiếng", "catalog", kind="danh-sach", slug="phim-long-tieng", page="1")
    add_dir("🎭 Thể loại", "genres")
    add_dir("🌍 Quốc gia", "countries")
    add_dir("🔎 Tìm kiếm", "search")
    xbmcplugin.endOfDirectory(HANDLE)

def genres():
    for name, slug in GENRES:
        add_dir(name, "catalog", kind="the-loai", slug=slug, page="1")
    xbmcplugin.endOfDirectory(HANDLE)

def countries():
    for name, slug in COUNTRIES:
        add_dir(name, "catalog", kind="quoc-gia", slug=slug, page="1")
    xbmcplugin.endOfDirectory(HANDLE)

def render_movies(data, next_action=None, next_page=None, next_kwargs=None):
    items, prefix = extract_items(data)
    for m in items:
        name = m.get("name") or m.get("origin_name") or "Không tên"
        slug = m.get("slug") or ""
        poster = full_image(m.get("poster_url") or m.get("thumb_url") or "", prefix)
        label = name
        year = m.get("year")
        episode = m.get("episode_current")
        if year: label += " (%s)" % year
        if episode: label += " - %s" % episode
        if slug:
            add_dir(label, "detail", {"poster": poster, "thumb": poster}, slug=slug, poster=poster)
    if next_action and items:
        kw = dict(next_kwargs or {})
        kw["page"] = str(next_page)
        add_dir("Trang tiếp theo ▶", next_action, **kw)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)

def latest(page):
    url = API + "/danh-sach/phim-moi-cap-nhat?page=" + urllib.parse.quote(str(page))
    data = get_json(url)
    render_movies(data, "latest", int(page)+1)

def catalog(kind, slug, page):
    url = API + "/v1/api/%s/%s?%s" % (
        urllib.parse.quote(kind), urllib.parse.quote(slug),
        urllib.parse.urlencode({"page": page, "limit": 24})
    )
    data = get_json(url)
    render_movies(data, "catalog", int(page)+1, {"kind": kind, "slug": slug})

def detail(slug, poster=""):
    data = get_json(API + "/phim/" + urllib.parse.quote(slug))
    episodes = data.get("episodes", []) if isinstance(data, dict) else []
    movie = data.get("movie", {}) if isinstance(data, dict) else {}
    if not poster and isinstance(movie, dict):
        poster = full_image(movie.get("poster_url") or movie.get("thumb_url") or "")
    count = 0
    for server in episodes:
        sname = server.get("server_name", "Server")
        for ep in server.get("server_data", []):
            stream = ep.get("link_m3u8") or ep.get("link_embed")
            if not stream: continue
            epname = ep.get("name", "")
            add_play("%s - Tập %s" % (sname, epname), stream, {"poster": poster, "thumb": poster})
            count += 1
    if not count: notify("Phim chưa có nguồn phát.")
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)

def search():
    q = xbmcgui.Dialog().input("Nhập tên phim", type=xbmcgui.INPUT_ALPHANUM)
    if not q:
        xbmcplugin.endOfDirectory(HANDLE); return
    url = API + "/v1/api/tim-kiem?" + urllib.parse.urlencode({"keyword": q, "limit": 50})
    render_movies(get_json(url))

def play(url):
    li = xbmcgui.ListItem(path=url)
    if ".m3u8" in url.lower():
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action")
try:
    if not action: home()
    elif action == "latest": latest(params.get("page", "1"))
    elif action == "catalog": catalog(params.get("kind", "danh-sach"), params.get("slug", "phim-le"), params.get("page", "1"))
    elif action == "genres": genres()
    elif action == "countries": countries()
    elif action == "detail": detail(params.get("slug", ""), params.get("poster", ""))
    elif action == "search": search()
    elif action == "play": play(params.get("url", ""))
except Exception as e:
    xbmc.log("Athienne error: " + repr(e), xbmc.LOGERROR)
    notify("Lỗi: " + str(e)[:120])
    try: xbmcplugin.endOfDirectory(HANDLE)
    except Exception: pass
